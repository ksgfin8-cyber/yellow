from pathlib import Path
import subprocess, json, hashlib, os, time, signal
repo=Path('/workspace/yellow'); os.chdir(repo)
root=Path('/workspace/shared/world-lab'); source=root/'p01-final-20261113-01'; copy=Path(str(source)+'-evidence'); ops=Path(str(source)+'-ops'); auth=root/'p01-authorization'
freeze='47155590f10358f6130a1f7eae261ec9ec1fc8035652c04dd23fcc9f92c63e7d'; key='918d051d30ea8b193e554928953836d3c15e86e910ef9f5a5d1323e90cf0866a'
inputs=json.loads(Path('/tmp/p01-signed-preflight-inputs.json').read_text()); original=Path(inputs['directory'])
assert not os.environ.get('NODE_OPTIONS'), 'HOLD: NODE_OPTIONS'
assert not subprocess.check_output(['git','status','--porcelain']).strip(), 'HOLD: dirty checkout'
assert not source.exists() and not copy.exists(), 'HOLD: campaign or copy exists'
for f in inputs['files']:
 b=(original/f['file']).read_bytes(); assert len(b)==f['bytes'] and hashlib.sha256(b).hexdigest()==f['sha256'], 'HOLD: original bytes differ'
assert auth.is_dir() and ops.is_dir()
assert (ops/'start-approval.txt').read_text().startswith('P01-E3-OWNER-START-APPROVAL-20261114-01')
for name,target in [('authorization.json','authorization.json'),('authorization.sig','authorization.sig'),('public.pem','owner-ed25519-public.pem')]:
 assert (auth/target).read_bytes()==(original/name).read_bytes()
assert not (ops/'controller.pid').exists(), 'HOLD: prior controller'
with (ops/'owner-explicit-chat-approval.txt').open('x') as out:
 out.write('Owner explicitly authorized in the chat: execute once the 256 final episodes of WORLD-LAB P01, campaign p01-final-20261113-01, freeze 47155590f10358f6130a1f7eae261ec9ec1fc8035652c04dd23fcc9f92c63e7d, destination /workspace/shared/world-lab/p01-final-20261113-01. Preserve evidence, no scientific changes, no automatic retries. E3 only.\n')
for name in ['check.json','check.stderr']:
 (ops/name).rename(ops/('sandbox-attempt-'+name))
base=['node','tools/p01/evaluation/cli.cjs']; proposal='docs/f6-e/P01-evaluation-freeze.json'; args=[proposal,str(auth/'authorization.json'),str(auth/'authorization.sig'),str(auth/'owner-ed25519-public.pem'),freeze,key]
for stage,cmd in [('check',base+['check',proposal]),('preflight',base+['preflight']+args)]:
 with (ops/(stage+'.json')).open('xb') as out, (ops/(stage+'.stderr')).open('xb') as err:
  r=subprocess.run(cmd,stdout=out,stderr=err)
 assert r.returncode==0, 'HOLD: '+stage
 d=json.loads((ops/(stage+'.json')).read_text()); assert d['freeze_id']==freeze
 if stage=='preflight': assert d['signature']=='VALID' and d['episodes_started']==0 and d['output_directory']==str(source)
print('Preconditions PASS; original bytes intact; owner approval registered.',flush=True)
watch_script=ops/'watch-wait.sh'
watch_script.write_text('''#!/bin/bash
set -eu
printf 'WAITING_FOR_EXECUTION_LOG\\n' >&2
for ((attempt=0; attempt<300; attempt++)); do
 if test -f "$1/execution.jsonl"; then
  exec node tools/evidence/preserve.cjs watch "$1" "$2" --campaign p01-final-20261113-01 --identity "$3" --interval-ms 15000
 fi
 sleep 1
done
echo 'HOLD: execution log did not appear' >&2
exit 1
''')
with (ops/'watch.jsonl').open('xb') as wout, (ops/'watch.stderr').open('xb') as werr:
 watcher=subprocess.Popen(['bash',str(watch_script),str(source),str(copy),freeze],stdout=wout,stderr=werr)
 (ops/'watch.pid').write_text(str(watcher.pid)+'\n')
 for _ in range(30):
  if b'WAITING_FOR_EXECUTION_LOG' in (ops/'watch.stderr').read_bytes(): break
  time.sleep(.1)
 assert watcher.poll() is None and b'WAITING_FOR_EXECUTION_LOG' in (ops/'watch.stderr').read_bytes(), 'HOLD: watcher not ready'
 assert not source.exists() and not copy.exists() and not subprocess.check_output(['git','status','--porcelain']).strip()
 print('Watcher ready and waiting; starting controller ONCE.',flush=True)
 with (ops/'controller.stdout').open('xb') as cout, (ops/'controller.stderr').open('xb') as cerr:
  controller=subprocess.Popen(base+['run']+args,stdout=cout,stderr=cerr)
  (ops/'controller.pid').write_text(str(controller.pid)+'\n')
  rc=controller.wait()
 (ops/'controller.exit').write_text(str(rc)+'\n')
 print('Controller exit: '+str(rc),flush=True)
 if watcher.poll() is None:
  cmdline=Path('/proc/'+str(watcher.pid)+'/cmdline').read_bytes()
  assert str(source).encode() in cmdline and (b'preserve.cjs' in cmdline or str(watch_script).encode() in cmdline), 'HOLD: watcher process identity'
  (ops/'watch-process-at-stop.txt').write_bytes(cmdline.replace(b'\x00',b' '))
  watcher.send_signal(signal.SIGTERM)
  try: watcher.wait(timeout=20)
  except subprocess.TimeoutExpired:
   print('HOLD: watcher did not stop; do not force kill',flush=True); raise
 (ops/'watch.exit').write_text(str(watcher.returncode)+'\n')
for stage,cmd in [('snapshot-terminal',['node','tools/evidence/preserve.cjs','snapshot',str(source),str(copy),'--campaign','p01-final-20261113-01','--identity',freeze]),('copy-verify',['node','tools/evidence/verify.cjs',str(copy)])]:
 with (ops/(stage+'.json')).open('xb') as out, (ops/(stage+'.stderr')).open('xb') as err:
  result=subprocess.run(cmd,stdout=out,stderr=err)
 (ops/(stage+'.exit')).write_text(str(result.returncode)+'\n')
 print(stage+': '+str(result.returncode),flush=True)
print('E3 operational process finished; inspect evidence. No restart.',flush=True)

#!/bin/bash
set -eu
printf 'WAITING_FOR_EXECUTION_LOG\n' >&2
for ((attempt=0; attempt<300; attempt++)); do
 if test -f "$1/execution.jsonl"; then
  exec node tools/evidence/preserve.cjs watch "$1" "$2" --campaign p01-final-20261113-01 --identity "$3" --interval-ms 15000
 fi
 sleep 1
done
echo 'HOLD: execution log did not appear' >&2
exit 1

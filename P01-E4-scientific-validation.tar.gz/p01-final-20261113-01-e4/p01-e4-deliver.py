from pathlib import Path
import json,hashlib,tarfile,io,subprocess,datetime
repo=Path('/workspace/yellow');p=Path('/workspace/shared/world-lab/p01-final-20261113-01-e4');d=repo/'docs/p01-e4';d.mkdir()
load=lambda name:json.loads((p/name).read_text());r=load('E4-operational-result.json');ind=load('independent-metrics.json');desc=load('independent-descriptors.json');ctx=load('execution-context.json');assert r['E4']=='PASS' and desc['status']=='PASS'
sha=lambda b:hashlib.sha256(b).hexdigest();paired=ind['pairs'];controls=ind['descriptive_controls'];stats=ind['distribution']
fm=sum(x['frontier_memory_v1'] for x in paired);rn=sum(x['random'] for x in paired);ru=sum(x['rule'] for x in controls);wa=sum(x['wait'] for x in controls)
table='| Semilla | FrontierMemory | Random | D | Rule | Wait |\n|---|---:|---:|---:|---:|---:|\n'+'\n'.join(f"| {x['seed']} | {x['frontier_memory_v1']} | {x['random']} | {x['difference']} | {controls[i]['rule']} | {controls[i]['wait']} |" for i,x in enumerate(paired))
zone=datetime.timezone(datetime.timedelta(hours=-5));started=datetime.datetime.fromisoformat(ctx['started_at']).astimezone(zone);ended=datetime.datetime.fromisoformat(r['finished_at']).astimezone(zone)
report=f'''# WORLD-LAB P01 — Verificación científica E4

**E4 PASS / VERIFIED en el alcance P01. H_PLUS_SUPPORTED en la batería finita preregistrada.**
**C2 HOLD_EXTERNAL_BACKUP_PENDING / EXTERNAL_BACKUP_PENDING. E5 NOT_PERFORMED.**
La autorización expresa del propietario permite E4 antes de resolver el respaldo externo; no declara C2 completado ni exime la preservación posterior.

## Identidad y procedimiento efectivamente ejecutado

Campaña `p01-final-20261113-01`; Freeze ID `47155590f10358f6130a1f7eae261ec9ec1fc8035652c04dd23fcc9f92c63e7d`.
Checkout de ejecución limpio: `6fcc698681514a90e1dcd28a0f926967b2304884`, exactamente el exigido por el plan. Runtime Node v24.22.1/Linux x64, verificado mediante gate antes y después; binario SHA-256 `61ab14cd750fc24d5db53490ec5fc40f756e4b6e136b78cf7004265471d9bd1d`.
Plan publicado: docs/p01-e3-final/E4-plan.md, conservado byte a byte durante la ejecución (SHA-256 `{ctx['plan_sha256']}`).
Inicio: {started.isoformat()}; cierre operacional: {ended.isoformat()} (America/Guayaquil).
El cierre operacional precede a la redacción y publicación de este informe.

Se usaron destinos nuevos y exclusivos, fuera del repositorio: p01-final-20261113-01-restored y p01-final-20261113-01-e4, bajo /workspace/shared/world-lab. Son **rutas históricas locales**, no enlaces públicos ni respaldo externo. No hubo ejecución de agentes, nuevos episodios, reintentos E3, cambios de semillas, métricas, exclusiones, contratos, expectativas o fuentes científicas.

## Integridad y restauración

- Se reverificaron los 256 pares raw/wlx, campos tipados, procedencia, firma y recibo, manifiesto, log y orden exacto de las 256 combinaciones. Solo lectura antes de restaurar.
- El tar E3 original conserva SHA-256 `8a1df2ac58fa2069afa4de52368097d79859b59e4b784e99a72966fa5690b7c7`; todos los miembros enumerados por su inventario interno se verificaron sin regenerar el paquete.
- Copia incremental: COPY_VERIFIED / SOURCE_COMPLETE, 774 objetos históricos y 256 índices; 255 versiones normales APPEND_ONLY_LOG_VERSION y cero conflictos bloqueantes.
- Restauración nueva: VERIFIED_COMPLETE_EVIDENCE; **519 archivos idénticos byte a byte** a la fuente E3 y al manifiesto SHA-256. Fuente E3, copia, OPS, auditoría y exportación conservaron el inventario íntegro antes/después.
- Gate y verificación de la copia original y restaurada al terminar: todos con salida 0 y sin errores. Repositorio limpio durante E4. Los cambios de publicación posteriores son únicamente documentales.

## Reproducción y determinismo

**256/256 replay restaurados MATCH, 0 MISMATCH**, con nuevas pruebas COMPLETE_MATCH idénticas a las archivadas. No se reutilizó el rótulo E3 como sustituto de ejecutar el replay.
Se verificaron 40.960 transiciones registradas y **41.216 estados** (incluido el inicial por episodio), con **82.432 comparaciones de bytes WLS1 WORLD/FULL** entre trayectoria y reproducción, además de comparaciones estructurales de registros/eventos/estados/contexto y terminación mediante el verificador existente.
Las 128 parejas de repeticiones son idénticas en todo artifact.data; se excluyen exclusivamente UUID, tiempos y procedencia operacional de esa igualdad. Los 32 mundos iniciales coinciden estructuralmente y por bytes WLS1 FULL entre los ocho episodios de cada semilla; cada replay también comprobó su correspondencia con el mundo inicial derivado de la semilla. Los bytes WORLD se contrastaron en cada estado contra su reproducción.
Las 256 combinaciones semilla/agente/repetición se preservan sin duplicados ni omisiones. Ningún escenario fue excluido. Fallos operacionales, de agente, inicialización, replay o descriptores: **0**.

## Independencia de las métricas y contrastes

Se ejecutó tools/evidence/p01-independent-metrics.cjs sobre la raíz restaurada: EVALUABLE, 32 pares elegibles, errores vacíos. Este oráculo no importa tools/p01/metrics.cjs y cuenta los RecordedEvent source=action/type=RESOURCE_CONSUMED; no usa analysis.json como fuente de la métrica.
Un script operacional separado recuenta directamente desde las trayectorias todos los descriptores preregistrados: consumos por ubicación, unicidad con regeneración=0, cobertura, acciones rechazadas por validity/reason, pasos/duración, recursos iniciales y terminación. Sus **256 filas coinciden íntegramente** con analysis.json. Recalcula también las 32 diferencias/distribución/controles y las contrasta campo por campo con el oráculo y el agregado archivado.
En otro proceso se llamó al measure existente del controlador sobre los datos restaurados: sus 256 filas también coinciden. Este último cálculo es corroboración del cálculo original, no se presenta como implementación independiente.

## Resultado principal preregistrado

C = consumos de recursos; D(seed) = C(FrontierMemory-v1) − C(RandomAgent).
Se usa una observación por semilla después de verificar sus dos repeticiones; **n=32, no 64**. La segunda repetición no aumenta el tamaño de la muestra.

| Estadístico | Resultado |
|---|---:|
| Suma D | {stats['sum']} |
| Media D | {stats['mean']} |
| Mediana D | {stats['median']} |
| Mínimo D / máximo D | {stats['min']} / {stats['max']} |
| Victorias / empates / derrotas | {stats['wins']} / {stats['ties']} / {stats['losses']} |
| Escenarios intentados / elegibles / excluidos | 32 / 32 / 0 |
| FrontierMemory: suma C / media C | {fm} / {fm/32} |
| Random: suma C / media C | {rn} / {rn/32} |

**Dictamen científico E4:** H+ sostenida en esta batería/configuración porque la suma de diferencias =356>0 y la media =11,125>0, con evidencia técnica y métricas concordantes. Esta condición es la preregistrada; no se introdujeron umbrales ni métricas después de observar resultados.

## Tabla completa y controles descriptivos

{table}

Rule: suma {ru}, media {ru/32}; Wait: suma {wa}, media {wa/32}. Son controles secundarios descriptivos, sin hipótesis confirmatorias nuevas ni selección de otra comparación principal. Las métricas completas por episodio están en los JSON adjuntos y la tabla se conserva también en CSV.

## Límites y anomalías

No se detectó discrepancia material. No se corrigió ni omitió evidencia original. Los 12 comandos del protocolo ejecutado terminaron con salida 0; sus stderr están vacíos. No fue necesario repetir operaciones para ocultar fallos.

La independencia corresponde al recuento y contraste de métricas y al uso de archivos restaurados; el replay reutiliza el mismo motor y validadores aprobados. No demuestra interoperabilidad con una implementación independiente ni constituye revisión por otro equipo.
El resultado se limita a estas 32 semillas consecutivas y a P01: no son una muestra IID de una población global. No se estimaron p-values o intervalos inferenciales. No atribuye causalmente el efecto a la memoria sola (la política combina memoria y planificación), ni demuestra entrenamiento, eficacia general, hazards o multiagente. Los tiempos del host no se usan como benchmark entre algoritmos.
C2 permanece HOLD_EXTERNAL_BACKUP_PENDING. La restauración y el nuevo paquete E4 son locales al mismo workspace; no prueban durabilidad externa. E5 y cualquier conformidad normativa global continúan fuera del alcance.

## Comandos, resultados e identificación de evidencia

[Protocolo ejecutado y scripts](verification/README.md), [registro de comandos](verification/commands.jsonl), [integridad/restauración](integrity-results.json), [métricas independientes completas](independent-metrics.json), [descriptores y repeticiones](independent-descriptors.json), [recálculo del controlador](controller-recount.json), [256 resultados de replay](replay-results.json), [mundos iniciales/WLS1](initial-world-WLS1-comparison.json), [CSV pareado](paired-results.csv) y [manifiesto de integridad](E4-evidence-manifest.json).
Las salidas completas originales y los inventarios antes/después permanecen en el expediente externo identificado por hashes. Ninguna referencia histórica /workspace o /tmp se presenta como enlace público. La publicación no sobrescribe el plan ni los informes históricos E3.
'''
with (p/'E4-report.md').open('x') as f:f.write(report)
(d/'E4-report.md').write_bytes((p/'E4-report.md').read_bytes())
for name in ['independent-metrics.json','independent-descriptors.json','controller-recount.json','paired-results.csv','initial-world-WLS1-comparison.json','E4-operational-result.json']:(d/name).write_bytes((p/name).read_bytes())
raw=[json.loads(l) for l in (p/'restored-replay.stdout').read_text().splitlines()];cases=raw[:-1]
replay={'status':'PASS','total':256,'failed':0,'rows':[{'seed':r['seed'],'agent':r['agent'],'repetition':r['repetition'],'status':r['status'],'proof_status':r['proof']['status'],'states_verified':r['proof']['states_verified'],'payload_sha256':r['proof']['payload_sha256'],'initial_full_WLS1_sha256':sha(bytes.fromhex(r['proof']['initial_full_hex'])),'comparison_with_archived_proof':'EXACT_MATCH'} for r in cases],'full_output_historical_reference':str(p/'restored-replay.stdout'),'full_output_sha256':sha((p/'restored-replay.stdout').read_bytes())}
(d/'replay-results.json').write_text(json.dumps(replay,indent=2)+'\n')
integ={'status':'PASS','restoration_byte_comparison':load('restoration-byte-comparison.json'),'restoration':load('restore.stdout'),'copy_before':load('copy-before.stdout'),'copy_after':load('copy-after.stdout'),'restored_before':load('restored-verify.stdout'),'restored_after':load('restored-after.stdout'),'historical_inventory_before_sha256':sha((p/'historical-inputs-before.json').read_bytes()),'historical_inventory_after_sha256':sha((p/'historical-inputs-after.json').read_bytes()),'gate_before':load('gate-before.stdout'),'gate_after':load('gate-after.stdout'),'C2':'HOLD_EXTERNAL_BACKUP_PENDING'}
(d/'integrity-results.json').write_text(json.dumps(integ,indent=2)+'\n')
v=d/'verification';v.mkdir()
for name in ['p01-e4-operation.py','p01-e4-integrity-check.cjs','p01-e4-independent-descriptors.cjs','p01-e4-controller-recount.cjs','p01-e4-restored-replay.cjs','commands.jsonl','execution-context.json']:(v/name).write_bytes((p/name).read_bytes())
(v/'README.md').write_text('''# Procedimiento E4 efectivamente ejecutado

Estos scripts operacionales se conservan con sus bytes ejecutados. No forman parte del motor científico ni cambian sus algoritmos. Las rutas absolutas son referencias históricas del workspace; no son URLs públicas ni se deben ejecutar ciegamente en un checkout de publicación.

El orquestador se ejecutó con `python /tmp/p01-e4-operation.py` desde /workspace/yellow, en HEAD limpio 6fcc698681514a90e1dcd28a0f926967b2304884. Se conservaron el plan publicado y su SHA-256 antes de cambiar de checkout. Los destinos restored/e4 eran inexistentes. El script usa creación exclusiva y no reanuda ni sustituye evidencia.

Los comandos exactos, tiempos UTC, códigos de salida y script stdin están en commands.jsonl. Secuencia: gate-before; integridad de solo lectura; copy-before; restore; restored-verify; independent-metrics; independent-descriptors; controller-recount; restored-replay (node por stdin, bloque idéntico al plan); gate-after; copy-after; restored-after. **12/12 salidas 0**. No se ejecutó cli.cjs run ni un agente.

El recuento independiente de descriptores importa solo el codec; el recálculo del controlador importa measure en un proceso separado. No se cambian descriptores históricos para hacerlos coincidir. El replay ejecuta el verificador existente con perfil final explícito, sobre los archivos restaurados.

Los scripts escriben únicamente resultados nuevos fuera del repositorio; requieren los originales para comprobación y no son una nueva API pública. Para reproducir E4 de nuevo deben elegirse salidas exclusivas y autorización operacional, conservando la primera evidencia, sin repetir E3.
''')
(d/'README.md').write_text('''# P01 — E4: validación científica sobre evidencia restaurada

**E4 PASS. H_PLUS_SUPPORTED en la batería finita preregistrada.**
**C2 HOLD_EXTERNAL_BACKUP_PENDING; E5 NOT_PERFORMED.**

- [Informe y tabla completa de 32 semillas](E4-report.md).
- [CSV de comparación principal y controles](paired-results.csv).
- [Métricas independientes de 256 episodios](independent-metrics.json).
- [Descriptores completos y 128 parejas de repeticiones](independent-descriptors.json).
- [Recálculo del controlador](controller-recount.json).
- [Resultados de 256 replay restaurados](replay-results.json).
- [Comparación de mundos iniciales/WLS1](initial-world-WLS1-comparison.json).
- [Integridad y restauración](integrity-results.json).
- [Resultado operacional](E4-operational-result.json).
- [Manifiesto de evidencia](E4-evidence-manifest.json).
- [Comandos y scripts efectivamente ejecutados](verification/README.md).
- [Cierre E3 preservado](../p01-e3-final/README.md) y [plan E4 histórico](../p01-e3-final/E4-plan.md).

La autorización del propietario permite avanzar E4 con respaldo externo pendiente; no declara C2 completado. Los 519 archivos originales y sus copias siguen fuera de Git e intactos. Este expediente publica informes, métricas y diagnósticos; no incluye trayectorias completas, archivos raw/wlx ni claves. Las rutas /workspace y /tmp son históricas; no son enlaces de descarga pública.

No se modificó código científico ni contrato. Las conclusiones no equivalen a aceptación E5, conformidad global o interoperabilidad independiente. No hay merge automático.
''')
# Freeze complete external E4 result set, preserving original E3 package and exports untouched.
(p/'p01-e4-deliver.py').write_bytes(Path('/tmp/p01-e4-deliver.py').read_bytes())
inventory=[{'file':str(f.relative_to(p)),'bytes':f.stat().st_size,'sha256':sha(f.read_bytes())} for f in sorted(p.rglob('*')) if f.is_file()]
with (p/'E4-SHA256.json').open('x') as f:json.dump(inventory,f,indent=2);f.write('\n')
exp=Path(str(p)+'-exports');exp.mkdir();package=exp/'P01-E4-scientific-validation.tar.gz'
with package.open('xb') as output:
 with tarfile.open(fileobj=output,mode='w:gz') as tar:
  for f in sorted(p.rglob('*')):
   if f.is_file():
    b=f.read_bytes();info=tarfile.TarInfo(p.name+'/'+str(f.relative_to(p)));info.size=len(b);info.mode=0o600;info.mtime=0;tar.addfile(info,io.BytesIO(b))
ph=sha(package.read_bytes());(exp/(package.name+'.sha256')).write_text(ph+'  '+package.name+'\n')
with tarfile.open(package,'r:gz') as tar:
 for member in tar.getmembers():
  assert member.isfile();assert tar.extractfile(member).read()==(p.parent/member.name).read_bytes()
manifest={'format':'WL-P01-E4-EVIDENCE-1','E4':'PASS','C2':'HOLD_EXTERNAL_BACKUP_PENDING','external_backup':'EXTERNAL_BACKUP_PENDING','E5':'NOT_PERFORMED','freeze_id':'47155590f10358f6130a1f7eae261ec9ec1fc8035652c04dd23fcc9f92c63e7d','execution_checkout':ctx['checkout'],'publication_base':subprocess.check_output(['git','rev-parse','origin/main'],cwd=repo,text=True).strip(),'approved_plan_sha256':ctx['plan_sha256'],'E3_export_sha256':ctx['export_sha256'],'result':r,'external_results_historical_reference':str(p),'external_results_inventory':inventory,'E4_package':{'historical_reference':str(package),'bytes':package.stat().st_size,'sha256':ph,'role':'E4 results only; requires original E3 package for input recovery','external_receipt_verified':False},'publication_note':'Reports, metric rows, bounded replay diagnostics and executed verification scripts only. No original episode archives or keys. Absolute paths are historical references, not public URLs.'}
(d/'E4-evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(d/'PUBLICATION-SHA256.json').write_text(json.dumps([{'file':str(f.relative_to(d)),'bytes':f.stat().st_size,'sha256':sha(f.read_bytes())} for f in sorted(d.rglob('*')) if f.is_file()],indent=2)+'\n')
print(json.dumps({'E4':'PASS','scientific_result':r['scientific_result'],'distribution':stats,'means':{'frontier_memory_v1':fm/32,'random':rn/32,'rule':ru/32,'wait':wa/32},'E4_package_sha256':ph,'E4_package_bytes':package.stat().st_size,'public_files':len(list(d.rglob('*'))),'C2':'HOLD_EXTERNAL_BACKUP_PENDING','E5':'NOT_PERFORMED'},indent=2))

from pathlib import Path
import subprocess,json,hashlib,datetime,sys
root=Path('/workspace/yellow');ops=Path('/workspace/shared/world-lab/wl-rc1/pilot-rc1-cd-v1-ops');pub=Path('/workspace/shared/world-lab/wl-rc1/authorization-public-20261118');target=ops.parent/'pilot-rc1-cd-v1'
freeze='466e1dc53f6d5f6f0fe144d85e7f65643b01244acabee5b8caaa25dd34df15ac';pin='3e65dff25d532c34504a2ddd317f85d8f66b0ba066277ffe634463380f521b5e'
assert not target.exists() and not (ops/'STARTED.json').exists()
files=subprocess.check_output(['git','ls-files','-z'],cwd=root).decode().split('\0');files=[f for f in files if f];before={f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in files};(ops/'tracked-before.json').write_text(json.dumps(before,indent=2)+'\n')
inputs={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in [pub/'authorization.json',pub/'authorization.sig',pub/'public.pem']};(ops/'public-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
base=['node','--max-old-space-size=512','tools/research/wl-rc1/cli.cjs'];args=['docs/research/wl-rc1-cd/PILOT-CANDIDATE.json',str(pub/'authorization.json'),str(pub/'authorization.sig'),str(pub/'public.pem'),freeze,pin]
p=subprocess.run(base+['preflight']+args,cwd=root,capture_output=True)
(ops/'preflight.json').write_bytes(p.stdout);(ops/'preflight.stderr').write_bytes(p.stderr)
assert p.returncode==0,p.stderr.decode();preflight=json.loads(p.stdout);assert preflight['episodes_started']==0 and preflight['pilot_started']==False and preflight['signature']=='VALID' and preflight['freeze_id']==freeze and preflight['output_directory']==str(target)
assert not target.exists();command=base+['run-pilot']+args;start={'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command,'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'owner_order':'owner-start-approval.md','attempt':1,'automatic_retries':False}
with (ops/'STARTED.json').open('x') as f:f.write(json.dumps(start,indent=2)+'\n')
print(json.dumps({'preflight':'VALID','freeze_id':freeze,'launching_once':True,'output_directory':str(target)}),flush=True)
with (ops/'run-pilot.stdout.json').open('xb') as out,(ops/'run-pilot.stderr.txt').open('xb') as err:
 p=subprocess.Popen(command,cwd=root,stdout=out,stderr=err);(ops/'controller.pid').write_text(str(p.pid)+'\n');code=p.wait()
end={'ended_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':code,'retries':0};(ops/'EXIT.json').write_text(json.dumps(end,indent=2)+'\n');print(json.dumps(end),flush=True)

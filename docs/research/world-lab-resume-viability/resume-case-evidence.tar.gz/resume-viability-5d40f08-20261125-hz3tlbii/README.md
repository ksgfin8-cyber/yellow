# WORLD-LAB — Memory-agent resume viability, one fixed technical case

Source: 5d40f08fbb36c5bbe075628a5b9a9078ce9c017c. Node v24.22.1. Plan was written before the only harness invocation. No seed/cut/horizon tuning or execution retry occurred.

The reference uses the unchanged public run_experiment. The interruption injects a sentinel after Recorder.record_step has committed tick8; this is explicitly not an existing pause API or a new canonical terminal result. A fresh VM loads the same frozen sources for each continuation arm. Snapshot restore writes this implementation's ordinary agent fields; feedback reconstruction calls only reset/step on saved feedback and discards the eight regenerated prefix actions, checking equality. Each successful continuation then calls agent.step16times on current feedback: no saved future actions are supplied. Recorder's original prefix is reimported through its recording operations, without replaying physical transitions, to retain prior ActionResult and global sequences. This is an external prototype, not a claim of a public restart contract.

replay-control.json is different: it supplies16saved suffix actions to replay_trajectory, calls no agent, and begins a replay segment with null prior feedback and sequence0. api-probes.json preserves the failures of public positive-time Recorder adoption, a serialized opaque checkpoint, and original continuation feedback in a fresh replay segment. The public-run probe confirms initialization and reset; its intentional agent error stops at the first feedback.

Executed commands:

    node /tmp/world-lab-resume-5d40f08-hz3tlbii/resume-harness.cjs > /tmp/world-lab-resume-5d40f08-hz3tlbii/execution.log 2>&1
    node /tmp/world-lab-resume-5d40f08-hz3tlbii/check-evidence.cjs

To reproduce, use a NEW empty directory, copy plan.json, resume-harness.cjs and check-evidence.cjs into it, and extract `git archive 5d40f08fbb36c5bbe075628a5b9a9078ce9c017c` into its source/ directory from a repository containing that commit. Run the two Node commands using that new path. Output writes use exclusive creation and will refuse overwriting evidence. The source/ export is deliberately excluded from the evidence package; all its662blobs were compared byte-for-byte with the target Git tree. Reproduction is a future explicit action, not automatically performed by these instructions.

Results: snapshot and feedback-history continuation have16new actions each and reproduce the entire continuous ExperimentResult structurally. The reset-only negative control first diverges at observation8/action tick9: expected MOVE_W to(2,2), actual MOVE_N to(3,1). Both still end MAX_TICKS_REACHED at24. The replay segment matches saved actions/states but not first feedback/sequence context. Pure postchecks compare134pairs of WORLD/FULL byte arrays and reconstruct all8prefix feedback from observations and previous ActionResults. These are dependent checks of one fixture, not134independent trials.

Repository before/after file hashes, source identity and clean worktree are preserved. The original repository HEAD remained0734e6f800796ae43f1821ed46093a9183080113; analysis used a separate byte-identical export of the requested5d40f08commit. No frozen source file was edited and no commit/PR was created.

Scope: same code/runtime, one nonterminal committed boundary, one FrontierMemory agent, fully exposed feedback, no regeneration/hazards,24ticks. Not a generic Agent checkpoint implementation, crash-consistent disk transaction, scientific campaign, or universal proof.

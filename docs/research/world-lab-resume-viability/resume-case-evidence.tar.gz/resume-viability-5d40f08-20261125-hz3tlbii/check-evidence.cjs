'use strict';
// Pure retrospective checks of saved outputs: no WORLD transition, agent.step or replay.
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const dir=__dirname,wire=require('./source/conformance/wire.cjs'),load=n=>wire.decode(JSON.parse(fs.readFileSync(path.join(dir,n),'utf8')));
const r=require('./source/tools/p01/runtime.cjs').loadRuntime();Object.assign(r.api,vm.runInContext('({build_feedback})',r.ctx));
const base=load('continuous.json').result.trajectory,cp=load('checkpoint.json'),cfg=load('plan.json');let checked=0,feedback=0;
function state(s){return new r.api.WorldState(s.time,r.realm(s.grid),r.realm(s.entities),s.rng_state,r.realm(cfg.world_config));}
function bytesEqual(a,b){for(const f of ['canonical_world_state_bytes','canonical_full_state_bytes']){assert.deepEqual(Buffer.from(r.api[f](state(a))),Buffer.from(r.api[f](state(b))));checked++;}}
for(const mode of ['snapshot','feedback_history']){const t=load('resumed-'+mode+'.json').result.trajectory;for(const [i,s] of [base.initial_state,...base.steps.map(x=>x.world_state)].entries())bytesEqual(s,[t.initial_state,...t.steps.map(x=>x.world_state)][i]);}
const rr=load('replay-control.json').result;bytesEqual(cp.world_state,base.steps[7].world_state);for(let i=0;i<rr.records.length;i++)bytesEqual(base.steps[i+8].world_state,rr.records[i].world_state);
let prior=null;for(const step of cp.records){const rebuilt=r.api.build_feedback(r.realm(step.observation),r.realm(prior),r.realm(cfg.feedback_config));assert.deepEqual(wire.encode(structuredClone(rebuilt)),wire.encode(step.feedback));prior=step.action_result;feedback++;}
const out={world_and_full_byte_pairs_equal:checked,snapshot_history_states_each:25,replay_suffix_states:16,cut_state:1,prefix_feedback_rebuilt_from_observations_and_prior_results:feedback,note:'Pure serializer/feedback reconstruction over saved outputs; no experimental transitions.'};fs.writeFileSync(path.join(dir,'postcheck.json'),JSON.stringify(out,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(out,null,2));
